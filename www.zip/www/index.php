<?php
include "classes/Parser.php";
include "classes/Database.php";
include "classes/Requests.php";

$oParser = new Parser("ressources/tickets_appels_201202.csv", 2);
$oParser->loadData();

$oRequests = new Requests();
echo "Total duration : " . $oRequests->get_total_calls_duration() . "<br><br>";
echo "Top 10 billed data outside 08h00/18h00 : <br>";
foreach ($oRequests->get_top10() as $aDataBilled) {
    echo $aDataBilled['volume_billed'] . "<br>";
}
echo "<br>";
echo "Total SMS : " . $oRequests->get_sum_sms() . "<br>";
