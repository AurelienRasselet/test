<?php
class Requests
{
    // Return duration of all calls, after 15/02/2012
    public function get_total_calls_duration()
    {
        $oConnexion = Database::get_instance();

        $aResult = $oConnexion->get_connexion()->query("
            SELECT sum(
                extract(hour from time_real) * 3600
                + extract(minute from time_real) * 60
                + extract(second from time_real)
          ) as sum_seconds
          FROM call_details
          WHERE call_date >= '2012-02-15'")->fetch();
        return sprintf('%02d:%02d:%02d', ($aResult['sum_seconds'] / 3600), ($aResult['sum_seconds'] / 60 % 60), $aResult['sum_seconds'] % 60);
    }

    // Return top 10 calls duration outside 08h-18h
    public function get_top10()
    {
        $oConnexion = Database::get_instance();

        $aResult = $oConnexion->get_connexion()->query("
            SELECT volume_billed
          FROM call_details
          WHERE HOUR(call_date) < 8
            OR HOUR(call_date) < 18
            ORDER BY volume_billed DESC
            LIMIT 10")->fetchAll();
        return $aResult;
    }

    // Return sum of all SMS sent
    public function get_sum_sms()
    {
        $oConnexion = Database::get_instance();

        $aResult = $oConnexion->get_connexion()->query("
            SELECT COUNT(call_id) as total_sms
            FROM call_details WHERE call_type
            LIKE '%envoi de sms depuis le mobile%'")->fetch();
        return $aResult['total_sms'];
    }

}
