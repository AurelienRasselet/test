<?php
class Database
{
    private $oConnexion;
    private static $instance = null;

    public function __construct()
    {
        $this->oConnexion = new PDO('mysql:host=localhost;dbname=gac_technology_test', 'root', '');
        $this->oConnexion->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

        // Emptying old data
        $this->oConnexion->query("DELETE FROM call_details");
    }

    // Singleton
    public static function get_instance()
    {
        if (is_null(self::$instance)) {
            self::$instance = new Database();
        }
        return self::$instance;
    }

    // Using transaction for saving execution time
    public function begin_transaction()
    {
        $this->oConnexion->beginTransaction();
    }

    public function commit()
    {
        $this->oConnexion->commit();
    }

    public function get_connexion()
    {
        return $this->oConnexion;
    }

    // Insert one call inside database
    public function insert($iAccountId, $iInvoiceId, $iSubscriberId, $sCallDay, $sCallHour, $sDataReal, $sDataBilled, $sCallType)
    {
        $oDateTime = DateTime::createFromFormat('d/m/Y H:i:s', $sCallDay . " " . $sCallHour);
        $sDate = null;
        if (!empty($oDateTime)) {
            $sDate = $oDateTime->format("Y/m/d H:i:s");
        }

        $oRequest = $this->oConnexion->prepare("INSERT INTO call_details (account_id, invoice_id, subscriber_id, call_date, time_real, volume_real, time_billed, volume_billed, call_type)
                                                     VALUES (:account_id, :invoice_id, :subscriber_id, :call_date, :time_real, :volume_real, :time_billed, :volume_billed, :call_type)");
        $oRequest->bindParam(':account_id', $iAccountId);
        $oRequest->bindParam(':invoice_id', $iInvoiceId);
        $oRequest->bindParam(':subscriber_id', $iSubscriberId);
        $oRequest->bindParam(':call_date', $sDate);

        // Quick check to know if data is time or volume
        $sTimeReal = "00:00:00";
        $sTimeBilled = "00:00:00";
        $fVolumeReal = 0;
        $fVolumeBilled = 0;
        if (preg_match('/[0-9][0-9]:[0-5][0-9]:[0-5][0-9]/', $sDataReal)) {
            $sTimeReal = $sDataReal;
        } elseif (!empty($sDataReal)) {
            $fVolumeReal = $sDataReal;
        }
        if (preg_match('/[0-2][0-9]:[0-5][0-9]:[0-5][0-9]/', $sDataBilled)) {
            $sTimeBilled = $sDataBilled;
        } elseif (!empty($sDataBilled)) {
            $fVolumeBilled = $sDataBilled;
        }

        $oRequest->bindParam(':time_real', $sTimeReal);
        $oRequest->bindParam(':volume_real', $fVolumeReal);
        $oRequest->bindParam(':time_billed', $sTimeBilled);
        $oRequest->bindParam(':volume_billed', $fVolumeBilled);

        $oRequest->bindParam(':call_type', $sCallType);

        $oRequest->execute();
    }
}
