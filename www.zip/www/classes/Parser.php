<?php
class Parser
{
    private $sFilePath;
    private $iFirstLine;

    public function __construct($sFilePath, $iFirstLine)
    {
        $this->sFilePath = $sFilePath;
        $this->iFirstLine = $iFirstLine;
    }

    // Load .csv data inside the table
    public function loadData()
    {
        if (!file_exists($this->sFilePath)) {
            echo "error";
            return '';
        }

        $iCount = 0;
        $oHandle = fopen($this->sFilePath, "r");
        if ($oHandle) {
            $oDatabase = Database::get_instance();
            $oDatabase->begin_transaction();

            while (($sLine = fgets($oHandle)) !== false) {

                if ($iCount > $this->iFirstLine) {
                    $aLineDetails = explode(";", $sLine);
                    $oDatabase->insert($aLineDetails[0], $aLineDetails[1], $aLineDetails[2], $aLineDetails[3], $aLineDetails[4], $aLineDetails[5], $aLineDetails[6], $aLineDetails[7]);
                }
                $iCount++;
            }

            fclose($oHandle);
            $oDatabase->commit();

        } else {
            echo "Error while loading the file";
        }
    }
}
