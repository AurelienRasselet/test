CREATE TABLE `call_details` (
  `call_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `account_id` int(10) unsigned NOT NULL,
  `invoice_id` int(10) unsigned NOT NULL,
  `subscriber_id` int(10) unsigned NOT NULL,
  `call_date` datetime DEFAULT NULL,
  `time_real` time DEFAULT NULL,
  `volume_real` decimal(10,3) DEFAULT NULL,
  `time_billed` time DEFAULT NULL,
  `volume_billed` decimal(10,3) DEFAULT NULL,
  `call_type` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`call_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;